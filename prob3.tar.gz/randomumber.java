import sun.reflect.generics.tree.Tree;

import java.util.Random;
import java.util.TreeSet;

/**
 * Created by admin02 on 25/5/16.
 */
public class randomumber {
    public static TreeSet<Integer> ts=new TreeSet<Integer>();
    public static TreeSet<Integer> lh=new TreeSet<Integer>();
    public boolean generateramdom(int n)
    {
        Random r=new Random();
        int num,i;
        for(i=0;i<n;i++)
        {
            do
            {
                num= r.nextInt(n);
            }while(ts.contains(num));
            ts.add(num);
        }
        if(ts.size()==n)
            return true;
        else
            return false;
    }
    public boolean find(int num)
    {
        if (ts.contains(num))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public TreeSet<Integer> findlowerandhigher(int num)
    {
        if (ts.contains(num))
        {
            lh.add(ts.lower(num));
            lh.add(ts.higher(num));
           return lh;
        }
        else
        {
            return lh;
        }
    }

}
