import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.*;

/**
 * Created by admin02 on 25/5/16.
 */
public class studentTest {
    @Test
    public void addstudent() throws Exception {
        student stud=new student();
        assertEquals("true",true,stud.addstudent("kavi",18));
        student stud1=new student();
        assertEquals("true",true,stud.addstudent("janani",19));
    }

    @Test
    public void getsizebyage() throws Exception {
        student stud=new student();
        assertEquals("true",true,stud.addstudent("kavi",18));
        student stud1=new student();
        assertEquals("true",true,stud.addstudent("janani",19));
        student stud2=new student();
        HashMap<Integer,Integer> expected=new HashMap<Integer,Integer>();
        expected.put(18,1);
        expected.put(19,1);
        assertEquals(expected,stud2.getsizebyage());

    }

}



