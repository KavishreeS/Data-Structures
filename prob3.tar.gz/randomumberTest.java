import org.junit.Test;

import java.util.TreeSet;

import static org.junit.Assert.*;

/**
 * Created by admin02 on 25/5/16.
 */
public class randomumberTest {
    @Test
    public void generateramdom() throws Exception {
        randomumber rand=new randomumber();
        assertEquals(true,rand.generateramdom(10));
    }

    @Test
    public void find() throws Exception {
        randomumber rand=new randomumber();
        assertEquals(true,rand.generateramdom(10));
        assertEquals(true,rand.find(5));

    }

    @Test
    public void findlowerandhigher() throws Exception {
        randomumber rand=new randomumber();
        TreeSet<Integer> expout=new TreeSet<Integer>();
        expout.add(4);
        expout.add(6);
        assertEquals(true,rand.generateramdom(10));
        assertEquals(true,rand.find(5));
        assertEquals(expout,rand.findlowerandhigher(5));
    }

}