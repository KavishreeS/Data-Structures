import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by admin02 on 25/5/16.
 */

class student
{
    String name;
    int age;
    public static HashMap<Integer,ArrayList<String>> h=new HashMap<Integer, ArrayList<String>>();
    public boolean addstudent(String sname,int sage)
    {
        this.name=sname;
        this.age=sage;
        return add();

    }
    public boolean add()
    {
        boolean flag=false;
        if(h.get(age)==null)
        {
            h.put(age,new ArrayList<String>());
            h.get(age).add(name);
            if(h.get(age).contains(name))
            {
                    flag= true;
            }
            else
            {
                flag= false;
            }


        }
        else
        {
            h.get(age).add(name);
            if(h.get(age).contains(name))
            {
                flag= true;
            }
            else
            {
                flag= false;
            }
        }

    return flag;
    }
    public HashMap<Integer,Integer> getsizebyage()
    {
        HashMap<Integer,Integer> size=new HashMap<Integer, Integer>();
        for (Map.Entry<Integer,ArrayList<String>> entry1:h.entrySet())
        {
            size.put(entry1.getKey(),entry1.getValue().size());
        }
        return size;
    }

}