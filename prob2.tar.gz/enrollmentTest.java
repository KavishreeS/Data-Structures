import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by admin02 on 25/5/16.
 */
public class enrollmentTest {

    @Test
    public void addstudent() throws Exception {
        int i;
        enrollment e[]=new enrollment[5];
        e[0]=new enrollment();
        assertEquals(true,e[0].addstudent("kavi","psg","cse"));
        e[1]=new enrollment();
        assertEquals(true,e[1].addstudent("shree","cit","cse"));
        e[2]=new enrollment();
        assertEquals(true,e[2].addstudent("janani","psg","mech"));
    }

    @Test
    public void getcourses() throws Exception {
        int i;
        enrollment enroll=new enrollment();
        enrollment e[]=new enrollment[5];
        e[0]=new enrollment();
        assertEquals(true,e[0].addstudent("kavi","psg","cse"));
        e[1]=new enrollment();
        assertEquals(true,e[1].addstudent("shree","cit","cse"));
        e[2]=new enrollment();
        assertEquals(true,e[2].addstudent("janani","psg","mech"));
        HashMap<String,Set<String>> expoutput=new HashMap<String,Set<String>>();
        expoutput.put("psg",new HashSet<String>());
        expoutput.get("psg").add("cse");
        expoutput.get("psg").add("mech");
        expoutput.put("cit",new HashSet<String>());
        expoutput.get("cit").add("cse");
        assertEquals(expoutput,enroll.getcourses());
    }

    @Test
    public void commoncourses() throws Exception {
        int i;
        enrollment enroll=new enrollment();
        enrollment e[]=new enrollment[10];
        for(i=0;i<10;i++)
        {
            e[i]=new enrollment();
        }
        assertEquals(true,e[0].addstudent("kavi","psg","cse"));
        assertEquals(true,e[1].addstudent("shree","cit","cse"));
        assertEquals(true,e[2].addstudent("janani","psg","mech"));
        assertEquals(true,e[3].addstudent("jananiram","cit","it"));
        assertEquals(true,e[4].addstudent("abi","gct","cse"));
        assertEquals(true,e[5].addstudent("jissy","cit","it"));
        assertEquals(true,e[6].addstudent("john","gct","mech"));
        assertEquals(true,e[7].addstudent("jobin","psg","mech"));
        HashSet<String> expout=new HashSet<String>();
        expout.add("cse");
        assertEquals(expout,enroll.commoncourses());

    }


}