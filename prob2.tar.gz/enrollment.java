import java.util.*;

/**
 * Created by admin02 on 25/5/16.
 */
public class enrollment {
    String studentname,collegename,coursename;
    public static HashMap<String,HashSet<String>> hm=new HashMap<String,HashSet<String>>();
    public boolean addstudent(String sname,String collname,String coursname)
    {
        this.studentname=sname;
        this.collegename=collname;
        this.coursename=coursname;
        return init();

    }
    public boolean init()
    {
        if(hm.get(collegename)==null)
        {
            hm.put(collegename,new HashSet<String>());
            hm.get(collegename).add(coursename);
        }
        else
        {
            hm.get(collegename).add(coursename);
        }
        if(hm.get(collegename).contains(coursename))
        {
            return true;
        }
        else
            return false;
    }
    public HashMap<String,HashSet<String>> getcourses()
    {
           return hm;
    }
    public HashSet<String> commoncourses()
    {
        HashSet<String> common=new HashSet<String>();
        for(HashSet<String> entry2 : hm.values())
        {
            if(common.isEmpty()) {
                common=entry2;
            }
            else
            {
                common.retainAll(entry2);
            }
        }
        return common;
    }

}
